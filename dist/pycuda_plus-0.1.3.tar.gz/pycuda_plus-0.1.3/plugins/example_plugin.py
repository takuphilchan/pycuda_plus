"""
Example of a custom plugin implementation.
"""
def example_function():
    """A simple example function for demonstration purposes."""
    print("Example plugin function executed.")